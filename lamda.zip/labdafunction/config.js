// config.js
module.exports = {
    DB_HOST: process.env.DB_HOST || 'datacomdb.cxi6uawy6aic.us-east-2.rds.amazonaws.com',
    DB_USER: process.env.DB_USER || 'admin1',
    DB_PASSWORD: process.env.DB_PASSWORD || 'lohith123',
    DB_NAME: process.env.DB_NAME || 'productsdb',
  };
  